# DFGraph

Is a simple graph based database library based on the `sqlalchemy` library.


## Installation

`pip install dfgraph`

## Usage

`dfgraph` comes with two main classes: `Node` and `Relationship`.



## Multithreating and Flask Integration